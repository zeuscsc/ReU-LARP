# terminal.js
Terminal.js is a lightweight, easy to use terminal interface for the web. (Note: This does not actually _run_ Javascript code)
Currently, terminal.js has only been tested on HTML, but it _should_ work on other platforms.

# Installation
Manually add the CSS and JS files to your project (make sure to also make a fake window in html to "host" the commands in) (Example in code)  
or `pip install terminaljs` (not supported yet)

# Usage
I'll add this soon...

# Screenshots
<img width="512" alt="terminal.js Image 1" src="https://user-images.githubusercontent.com/77017806/141518501-b9aec5fd-63f6-424f-bfca-5050ae8d4fd6.png">
<img width ="512" alt="terminal.js Gif 1" src = "https://user-images.githubusercontent.com/77017806/141521672-706d0084-b1c3-4f7b-b021-d5c5a8a74a36.gif">
